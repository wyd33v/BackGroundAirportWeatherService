﻿using System.Text.Json;
using Microsoft.Extensions.Hosting;
using System.Xml;

namespace BackGroundAirportWeatherService;

public class BackgroundAirportWeatherService : BackgroundService
{ 
    private readonly List<string> _airportCodes = new ();
    private string? _outputFolderPath;
    private readonly HttpClient _httpClient;

    public BackgroundAirportWeatherService()
    {
        LoadConfiguration();
        _httpClient = new HttpClient();
    }

    private void LoadConfiguration()
    {
        XmlDocument xmlDoc = new XmlDocument();
        xmlDoc.Load(@"D:\dev\RiderProjects\BackGroundAirportWeatherService\BackGroundAirportWeatherService\config.xml");

        XmlNodeList? airportNodes = xmlDoc.SelectNodes("/configuration/section[@name='Airports']/add");
        if (airportNodes != null)
            foreach (XmlNode airportNode in airportNodes)
            {
                string? airportCode = airportNode.Attributes?["value"]?.Value;
                if (airportCode != null)
                    _airportCodes.Add(airportCode);
            }
        XmlNode? outputFolderNode = xmlDoc.SelectSingleNode("/configuration/section[@name='OutputFolder']/add");
        _outputFolderPath = outputFolderNode?.Attributes?["value"]?.Value;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            if (_airportCodes != null)
                foreach (var airportCode in _airportCodes)
                {
                    var forecastData = await GetForecastDataAsync(airportCode, stoppingToken);
                    
                    if (forecastData.Value.ValueKind != JsonValueKind.Null)
                    {
                        await SaveForecastDataAsync(airportCode, forecastData, stoppingToken);
                    }
                }
            await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
        }
    }

    private async Task<JsonElement?> GetForecastDataAsync(string airportCode, CancellationToken cancellationToken)
    {
        var url = $"https://aviationweather.gov/api/data/taf?ids={airportCode}&format=json";
        
        var response = await _httpClient.GetAsync(url, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return null;
        }
        return await JsonSerializer.DeserializeAsync<JsonElement>(await response.Content.ReadAsStreamAsync(cancellationToken), cancellationToken: cancellationToken);
    }

    private async Task SaveForecastDataAsync(string airportCode, JsonElement? forecastData, CancellationToken cancellationToken)
    {
        if(forecastData == null || _outputFolderPath == null)
            return;
        
        var arrayElement = forecastData.Value.EnumerateArray().FirstOrDefault();

        if (arrayElement.ValueKind != JsonValueKind.Object)
            return;
        
        var issueTime = arrayElement.GetProperty("issueTime").GetString();
        var fileName = $"{airportCode}_{issueTime}_{DateTime.UtcNow:yyyyMMdd_HHmmss}".Replace(" ", "_")
            .Replace(":", "_") + ".json";
        
        Directory.CreateDirectory(_outputFolderPath);
        
        var filePath = Path.Combine(_outputFolderPath, fileName);
        await using var fileStream = File.Create(filePath);
        await JsonSerializer.SerializeAsync(fileStream, forecastData, cancellationToken: cancellationToken);
    }
}