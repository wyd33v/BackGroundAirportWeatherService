﻿
using BackGroundAirportWeatherService;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = Host.CreateDefaultBuilder(args);

builder.ConfigureServices((services) =>
{
    services.AddHostedService<BackgroundAirportWeatherService>();
});

builder.UseWindowsService();

var service = builder.Build();

service.Run();